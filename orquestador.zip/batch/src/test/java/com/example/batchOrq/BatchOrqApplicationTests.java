package com.example.batchOrq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatchOrqApplicationTests {

	@Test
	void contextLoads() {
	}

}
